package com.example.firecrud

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
